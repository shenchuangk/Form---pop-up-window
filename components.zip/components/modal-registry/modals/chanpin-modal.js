/**
 * 产品弹窗配置
 */
export const ModalConfig = {
  title: '产品管理',
  buttons: [
    { key: 'cancel', text: '取消', className: 'btn btn-cancel', action: 'close' },
    { key: 'submit', text: '确认添加', className: 'btn btn-submit', action: 'submit' }
  ],
  config: [
    {
      field: 'bianhao',
      title: '产品编号',
      type: 'text',
      required: true,
      placeholder: '请输入产品编号'
    }
  ],
  onSubmit: async (formData) => {
    try {
      const dataManager = window.parent?.dataManager || window.dataManager;
      if (!dataManager) {
        throw new Error('数据管理器未初始化');
      }
      
      await dataManager.addEntity('chanpin', formData);
      alert('产品创建成功！');
    } catch (error) {
      console.error('产品创建失败:', error);
      alert(`产品创建失败: ${error.message}`);
    }
  }
};

// 导出modal-registry需要的配置对象
export default ModalConfig