/**
 * 订单弹窗配置
 */
export const ModalConfig = {
  title: '订单管理',
  buttons: [
    { key: 'cancel', text: '取消', className: 'btn btn-cancel', action: 'close' },
    { key: 'submit', text: '确认保存', className: 'btn btn-submit', action: 'submit' }
  ],
  config: [
    {
      field: 'number',
      title: '订单编号',
      type: 'text',
      required: true,
      placeholder: '请输入订单编号'
    },
    {
      field: 'xiadan',
      title: '下单日期',
      type: 'date',
      required: true,
      value: new Date().toISOString().split('T')[0]
    },
    {
      field: 'jiaohuo',
      title: '交货日期',
      type: 'date',
      placeholder: '请选择交货日期'
    }
  ],
  onSubmit: async (formData) => {
    try {
      const dataManager = window.parent?.dataManager || window.dataManager;
      if (!dataManager) {
        throw new Error('数据管理器未初始化');
      }
      
      await dataManager.addEntity('dingdan', formData);
      alert('订单创建成功！');
    } catch (error) {
      console.error('订单创建失败:', error);
      alert(`订单创建失败: ${error.message}`);
    }
  }
};

// 导出modal-registry需要的配置对象
export default ModalConfig;