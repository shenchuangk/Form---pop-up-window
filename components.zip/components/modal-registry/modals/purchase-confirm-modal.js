/**
 * 确认提交采购信息弹窗配置
 * 用于在提交采购订单前显示详细信息确认
 */


// 确认提交采购信息弹窗配置
export const ModalConfig = {
    title: '确认提交采购信息',
    buttons: [
        { key: 'cancel', text: '取消', className: 'btn btn-cancel', action: 'close' },
        { key: 'submit', text: '确认采购', className: 'btn btn-submit', action: 'submit' }
    ],
    config: [
        {
            field: 'dingdan',
            title: '订单信息',
            type: 'text',
            readonly: true,
            placeholder: '订单编号和日期'
        },
        {
            field: 'chanpin', 
            title: '产品信息',
            type: 'text',
            readonly: true,
            placeholder: '产品编号和数量'
        },
        {
            field: 'zujian',
            title: '组件信息', 
            type: 'text',
            readonly: true,
            placeholder: '组件名称和产量'
        },
        {
            field: 'bancai',
            title: '板材信息',
            type: 'text',
            readonly: true,
            rows: 3,
            placeholder: '板材详细规格信息'
        },
        {
            field: 'quantity',
            title: '采购数量',
            type: 'number',
            readonly: true,
            min: 1,
            placeholder: '采购数量'
        },
        {
            field: 'submitDate',
            title: '提交时间',
            type: 'text',
            readonly: true,
            placeholder: '当前时间'
        },
        {
            field: 'operator',
            title: '操作员',
            type: 'text', 
            readonly: true,
            placeholder: '当前登录用户'
        },
        {
            field: 'remarks',
            title: '备注说明',
            type: 'textarea',
            rows: 2,
            placeholder: '可选填写特殊要求或说明'
        }
    ],

    /**
     * 弹窗显示前的数据预处理
     * @param {Object} orderData - 采购订单数据
     */
    beforeShow: async function(orderData) {
        console.log('准备显示采购确认弹窗，订单数据:', orderData);
        
        if (!orderData) {
            throw new Error('缺少订单数据');
        }
  const dataManager = window.parent.dataManager||window.dataManager ||{};
        
        // 获取当前用户信息
        const userId = localStorage.getItem('userId');
        const userName = localStorage.getItem('name') || '未知用户';
        
        // 格式化订单信息
        let orderInfo = '无订单信息';
        if (orderData.dingdanId) {
            const dingdan=  dataManager.data.dingdans.find(d => d.id == orderData.dingdanId);
            const orderDate = dingdan.xiadan ? 
                new Date(dingdan.xiadan).toLocaleDateString() : '未知日期';
            orderInfo = `${ dingdan.number || '未知订单'} (${orderDate})`;
        }

        // 格式化产品信息
        let productInfo = '无产品信息';
        if (orderData.chanpinId) {
            const chanpin = dataManager.chanpins.find(c => c.id == orderData.chanpinId);
            productInfo = `${chanpin.bianhao || '未知产品'}`;
        }

        // 格式化组件信息
        let componentInfo = '无组件信息';
        if (orderData.zujianId) {
            const   zujian = dataManager.zujians.find(z => z.id == orderData.zujianId);
            componentInfo = `${zujian.name || '未知组件'}`;
        }

        // 格式化板材信息
        let materialInfo = '无板材信息';
        if (orderData.bancai) {
            // 从dataManager获取完整的板材信息
          
            if (dataManager && dataManager.data.bancais) {
                const bancai = dataManager.data.bancais.find(b => b.id == orderData.bancaiId);
                if (bancai) {
                    materialInfo = formatBancaiInfo(bancai);
                }
            }
        }

     

        // 当前时间
        const submitDate = new Date().toLocaleString();
        const returnData = {
        
            dingdan: { value: orderInfo },
            chanpin: { value: productInfo },
            zujian: { value: componentInfo },
            bancai: { value: materialInfo },
            quantity: { value: orderData.shuliang || 0 },
            submitDate: { value: submitDate },
            operator: { value: userName },
            userId:userId,
            remarks: { value: '' }, ...orderData
        };
        console.log(returnData); 
        return {...returnData}
    },

    /**
     * 表单提交处理
     * @param {Object} formData - 表单数据
     */
    onSubmit: async function(formData) {
        console.log('确认提交采购信息:', formData);
        const dataManager = (window.parent?.dataManager || window.dataManager) ?? {};
        try {
            dataManager.transactionalOperation('submitDingdan_bancai',formData);
       
        } catch (error) {   
         
        }
    }
};

 
    // 新增函数：格式化板材信息
    function formatBancaiInfo(bancai) {
        let info = `厚度: ${bancai.houdu}mm, 材质: `;
        
        if (bancai.caizhi) {
            info += bancai.caizhi.name;
        }
        
        if (bancai.mupi1) {
            info += `, 木皮1: ${bancai.mupi1.name}${bancai.mupi1.you ? ' (油)' : ''}`;
        }
        
        if (bancai.mupi2) {
            info += `, 木皮2: ${bancai.mupi2.name}${bancai.mupi2.you ? ' (油)' : ''}`;
        }
        
        return info;
    }
    



// 导出modal-registry需要的配置对象
export default ModalConfig;