/**
 * 板材详情弹窗配置
 * modalName: material-detail-modal
 */
export const ModalConfig = {
  title: '板材详情',
  buttons: [
    { key: 'close', text: '关闭', className: 'btn btn-primary', action: 'close' }
  ],
  config: [
    { field: 'id', title: '板材ID', type: 'text', readonly: true },
    { field: 'caizhi', title: '材质', type: 'text', readonly: true },
    { field: 'houdu', title: '厚度(mm)', type: 'text', readonly: true },
    { field: 'mupi1', title: '木皮1', type: 'text', readonly: true },
    { field: 'mupi2', title: '木皮2', type: 'text', readonly: true },
    { field: 'kucun', title: '库存数量', type: 'text', readonly: true },
    { field: 'orders', title: '相关订单', type: 'textarea', rows: 6, readonly: true }
  ],
  beforeShow: function(initData) {
    try {
      const dataManager = window.parent?.dataManager || window.dataManager;
      if (!dataManager) return {};
      const bancaiId = initData?.bancaiId;
      if (!bancaiId) return {};
      const bancai = (dataManager.data.bancais || []).find(b => b.id == bancaiId);
      if (!bancai) return {};
      const kucun = (dataManager.data.kucuns || []).find(k => k.bancai && k.bancai.id == bancaiId);
      const formatMupi = (m) => !m ? '无' : `${m.name}${m.you ? '(油)' : ''}`;
      // 相关订单聚合
      const orderMap = new Map();
      const dczs = dataManager.data.dingdan_chanpin_zujians || [];
      dczs.forEach(x => {
        if (x.bancai?.id == bancaiId && x.dingdan) orderMap.set(x.dingdan.id, x.dingdan);
      });
      const dcs = dataManager.data.dingdan_chanpins || [];
      const czs = dataManager.data.chanpin_zujians || [];
      czs.forEach(cz => {
        if (cz.bancai?.id == bancaiId) {
          dcs.forEach(dc => {
            if (dc.chanpin?.id === cz.chanpin?.id && dc.dingdan) {
              orderMap.set(dc.dingdan.id, dc.dingdan);
            }
          });
        }
      });
      const dbs = dataManager.data.dingdan_bancais || [];
      dbs.forEach(db => {
        if (db.bancai?.id == bancaiId && db.dingdan) orderMap.set(db.dingdan.id, db.dingdan);
      });
      const ordersArr = Array.from(orderMap.values())
        .sort((a, b) => new Date(b.xiadan || 0) - new Date(a.xiadan || 0))
        .map(o => `订单号: ${o.number} 下单: ${o.xiadan ? new Date(o.xiadan).toLocaleDateString() : '-'} 交货: ${o.jiaohuo ? new Date(o.jiaohuo).toLocaleDateString() : '-'}`)
        .join('\n') || '无相关订单';
      return {
        id: { value: String(bancai.id) },
        caizhi: { value: bancai.caizhi?.name || '未知' },
        houdu: { value: bancai.houdu != null ? bancai.houdu.toFixed(1) : '' },
        mupi1: { value: formatMupi(bancai.mupi1) },
        mupi2: { value: formatMupi(bancai.mupi2) },
        kucun: { value: String(kucun?.shuliang || 0) },
        orders: { value: ordersArr }
      };
    } catch (e) {
      console.warn('material-detail-modal beforeShow error:', e);
      return {};
    }
  },
  // 仅查看，无需提交。返回 false 阻止提交，或不提供 onSubmit 默认关闭即可。
  onSubmit: function() {
    // 返回对象以触发 Promise resolve，保持统一交互
    return { ok: true };
  }
};

// 导出modal-registry需要的配置对象

export default ModalConfig;