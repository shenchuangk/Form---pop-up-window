/**
 * 材质弹窗配置
 */
export const ModalConfig = {
  title: '材质管理',
  buttons: [
    { key: 'cancel', text: '取消', className: 'btn btn-cancel', action: 'close' },
    { key: 'submit', text: '确认添加', className: 'btn btn-submit', action: 'submit' }
  ],
  config: [
    {
      field: 'name',
      title: '材质名称',
      type: 'text',
      required: true,
      placeholder: '请输入材质名称'
    }
  ],
  onSubmit: async (formData) => {
    try {
      const dataManager = window.parent?.dataManager || window.dataManager;
      if (!dataManager) {
        throw new Error('数据管理器未初始化');
      }
      
      await dataManager.addEntity('caizhi', formData);
      alert('材质创建成功！');
    } catch (error) {
      console.error('材质创建失败:', error);
      alert(`材质创建失败: ${error.message}`);
    }
  }
};

// 导出modal-registry需要的配置对象
export default ModalConfig