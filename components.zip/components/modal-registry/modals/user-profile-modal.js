/**
 * 个人资料弹窗配置
 */

// 权限选项配置（与Permission.java枚举对应）
const permissionOptions = [
  { value: 1, label: '查看' },
  { value: 2, label: '消耗' },
  { value: 4, label: '订购' },
  { value: 8, label: '库存调整' },
  { value: 16, label: '管理' }
];

// 个人资料弹窗配置
export const ModalConfig = {
  title: '个人资料',
  buttons: [
    { key: 'close', text: '关闭', className: 'btn btn-primary', action: 'close' }
  ],
  config: [
    {
      field: 'id',
      title: 'ID',
      type: 'hidden',
      value: ''
    },
    {
      field: 'name',
      title: '用户姓名',
      type: 'text',
      required: true,
      placeholder: '请输入用户姓名',
      readonly: true // 个人资料页面通常不允许修改姓名
    },
    {
      field: 'andy',
      title: '登录账号',
      type: 'text',
      required: true,
      placeholder: '请输入登录账号',
      readonly: true // 通常不允许修改登录账号
    },
    {
      field: 'permissions',
      title: '用户权限',
      type: 'checkbox-group',
      required: true,
      options: permissionOptions,
      disabled: true // 个人资料页面通常不允许修改权限
    },
    {
      field: 'incumbency',
      title: '在职状态',
      type: 'select',
      required: true,
      options: [
        { value: 1, label: '在职' },
        { value: 0, label: '离职' }
      ],
      disabled: true // 个人资料页面通常不允许修改在职状态
    },
    {
      field: 'loginTime',
      title: '最近登录时间',
      type: 'text',
      readonly: true,
      placeholder: '暂无登录记录'
    }
  ],
  
  // 弹窗显示前的数据处理
  beforeShow: async (data) => {
    try {
      // 从localStorage获取当前用户信息
      const username = localStorage.getItem("name");
      const userRole = localStorage.getItem("role");
      const loginDate = localStorage.getItem("Logindate");
      
      // 准备表单数据
      const formData = {
        id: { value: '' },
        name: { value: username || '' },
        andy: { value: username || '' }, // 假设登录账号也是用户名
        permissions: { value: [], disabled: true },
        incumbency: { value: 1, disabled: true }, // 默认为在职
        loginTime: { value: loginDate || '暂无登录记录', readonly: true }
      };
      
      // 处理权限数据 - 从单个数值转换为多选数组
      if (userRole) {
        const roleValue = parseInt(userRole);
        formData.permissions.value = permissionOptions
          .filter(option => (roleValue & option.value) === option.value)
          .map(option => option.value);
      }
      
      return formData;
    } catch (error) {
      console.error('加载个人资料数据失败:', error);
      alert(`加载失败: ${error.message}`);
      return {};
    }
  },
  
  // 提交表单数据（在个人资料页面通常只是查看，不允许提交修改）
  onSubmit: async (formData) => {
    try {
      // 个人资料页面通常不允许直接修改，提示用户通过其他方式修改
      alert('个人资料信息无法在此页面直接修改。如需修改密码，请使用"修改密码"功能。');
      return false; // 阻止弹窗关闭
    } catch (error) {
      console.error('操作失败:', error);
      alert(`操作失败: ${error.message}`);
      return false;
    }
  }
};

// 导出modal-registry需要的配置对象
export default ModalConfig