/**
 * 产品弹窗配置
 */
export const ModalConfig = {
  title: '订单产品管理',
  dingdanId: 0,
  buttons: [
    { key: 'cancel', text: '取消', className: 'btn btn-cancel', action: 'close' },
    { key: 'submit', text: '确认添加', className: 'btn btn-submit', action: 'submit' }
  ],
  config: [
    {
      field: 'chanpin',
      title: '产品',
      type: 'select2',
      required: true,
      placeholder: '请选择产品',
      button:{
        text:'新建产品',
        childModal:'chanpin-modal'
      }
    },
    {
      field:'shuliang',
      title:'数量',
      type:'number',
      min:1,
      value:1
      
    }
  ],
  beforeShow: async (dingdanId) => {

  // 构建可用产品列表（排除已包含的产品）
  const availableProducts = [];
  if(!dingdanId||dingdanId==='undefined'||dingdanId===0){
     return  {chanpin:{options:availableProducts}};
  }
  // 安全获取 dataManager
  const dataManager = (window.parent?.dataManager || window.dataManager) ?? {};
  
  // 确保数组存在（空数组作为后备）
  const dingdanCanpins = dataManager.data.dingdan_chanpins || [];
  const allChanpins = dataManager.data.chanpins || [];

    ModalConfig.dingdanId = parseInt(dingdanId) || 0;
  // 获取当前订单的所有产品ID
  const includedIds = dingdanCanpins
    .filter(cp => cp.dingdan?.id === ModalConfig.dingdanId) // 使用可选链防止错误
    .map(cp => cp.chanpin?.id)                  // 获取所有产品ID
    .filter(Boolean);                           // 过滤无效值

  for (const ch of allChanpins) {
    if (!includedIds.includes(ch.id)) {
      availableProducts.push({
        label: ch.bianhao,  // 显示文本
        value: `{"id":${ch.id}}`       // 实际值
      });
    }
  }
  console.log(availableProducts);
  return  {chanpin:{options:availableProducts},dingdan:{id:ModalConfig.dingdanId}}; // 返回对象数组
}
,
  onSubmit: async (formData) => {
    try {
      const dataManager = window.parent?.dataManager || window.dataManager;
      if (!dataManager) {
        throw new Error('数据管理器未初始化');
      }
       console.log(formData);
       formData.chanpin = JSON.parse(formData.chanpin);

      console.log(formData);
      return await dataManager.addEntity('dingdan_chanpin', formData);
     
    } catch (error) {
      console.error('产品创建失败:', error);
        return null;
    }
  }
};

// 导出modal-registry需要的配置对象
export default ModalConfig;