/**
 * 注销确认弹窗配置
 */

// 注销确认弹窗配置
export const ModalConfig = {
  title: '注销确认',
  buttons: [
    { key: 'cancel', text: '取消', className: 'btn btn-cancel', action: 'close' },
    { key: 'submit', text: '确认注销', className: 'btn btn-submit', action: 'submit' }
  ],
  config: [
    {
      field: 'confirmText',
      title: '',
      type: 'text',
      readonly: true,
      value: '确定要注销当前账号吗？注销后需要重新登录才能继续使用系统。',
      placeholder: '',
      style: 'font-size: 14px; color: #666; line-height: 1.5; padding: 10px 0;'
    }
  ],
  
  // 弹窗显示前的数据处理
  beforeShow: async (data) => {
    try {
      // 返回确认信息
      return {
        confirmText: { 
          value: '确定要注销当前账号吗？注销后需要重新登录才能继续使用系统。',
          readonly: true,
          style: 'font-size: 14px; color: #666; line-height: 1.5; padding: 10px 0;'
        }
      };
    } catch (error) {
      console.error('初始化注销确认表单失败:', error);
      alert(`初始化失败: ${error.message}`);
      return {};
    }
  },
  
  // 提交表单数据
  onSubmit: async (formData) => {
    try {
      // 清除登录状态
      localStorage.removeItem("name");
      localStorage.removeItem("role");
      localStorage.removeItem("isLoggedIn");
      localStorage.removeItem("Logindate");
      
      // 跳转到登录页
      window.location.href = 'login.html';
      
      return true;
    } catch (error) {
      console.error('注销失败:', error);
      alert(`注销失败: ${error.message}`);
      return false;
    }
  }
  };
  
  // 导出modal-registry需要的配置对象
export default ModalConfig;
