/**
 * 库存编辑弹窗配置
 */

export const ModalConfig = {
  title: '编辑库存',
  buttons: [
    { key: 'cancel', text: '取消', className: 'btn btn-cancel', action: 'close' },
    { key: 'submit', text: '确认调整', className: 'btn btn-submit', action: 'submit' }
  ],
  config: [
    {
      field: 'currentStock',
      title: '当前库存',
      type: 'text',
      readonly: true,
      required: false
    },
    {
      field: 'newStock',
      title: '新库存数量',
      type: 'number',
      required: true,
      min: 0
    },
    {
      field: 'adjustReason',
      title: '调整原因',
      type: 'text',
      required: false
    }
  ],
  beforeShow: function(initData) {
    if (!initData || !initData.kucun) {
      return {}
    }
    return {
      currentStock: {
        value: initData.kucun.shuliang || 0
      },
      newStock: {
        value: initData.kucun.shuliang || 0
      },
      adjustReason: {
        value: ''
      },
      kucun: initData.kucun
    }
  },
  onSubmit: async function(formData) {
    const { newStock, adjustReason, kucun } = formData
    
    if (!kucun) {
      throw new Error('库存记录不存在')
    }
    
    const oldStock = kucun.shuliang
    const changeAmount = newStock - oldStock
    
    if (changeAmount === 0) {
      throw new Error('库存未变化')
    }
    
    // 获取父窗口的dataManager
    const dataManager = window.parent.dataManager
    
    // 使用事务API更新库存
    return dataManager.Transaction.updateStock({
      kucunId: kucun.id,
      shuliang: newStock,
      text: adjustReason || "",
      userId: localStorage.getItem('userId') || 1
    })
  }
}

// 导出modal-registry需要的配置对象
export default ModalConfig;