/**
 * 修改密码弹窗配置
 */

// 修改密码弹窗配置
export const ModalConfig = {
  title: '修改密码',
  buttons: [
    { key: 'cancel', text: '取消', className: 'btn btn-cancel', action: 'close' },
    { key: 'submit', text: '确定修改', className: 'btn btn-submit', action: 'submit' }
  ],
  config: [
    {
      field: 'oldPassword',
      title: '当前密码',
      type: 'password',
      required: true,
      placeholder: '请输入当前密码'
    },
    {
      field: 'newPassword',
      title: '新密码',
      type: 'password',
      required: true,
      placeholder: '请输入新密码',
      minlength: 6,
      pattern: '^(?=.*[a-zA-Z])(?=.*\d).{6,}$',
      patternMessage: '密码必须包含字母和数字，且长度至少为6位'
    },
    {
      field: 'confirmPassword',
      title: '确认新密码',
      type: 'password',
      required: true,
      placeholder: '请再次输入新密码'
    }
  ],
  
  // 弹窗显示前的数据处理
  beforeShow: async (data) => {
    try {
      // 返回空的表单数据
      return {
        oldPassword: { value: '' },
        newPassword: { value: '' },
        confirmPassword: { value: '' }
      };
    } catch (error) {
      console.error('初始化密码修改表单失败:', error);
      alert(`初始化失败: ${error.message}`);
      return {};
    }
  },
  
  // 提交表单数据
  onSubmit: async (formData) => {
    try {
      const dataManager = window.parent?.dataManager || window.dataManager;
      if (!dataManager) {
        throw new Error('数据管理器未初始化');
      }
      
      // 验证两次输入的密码是否一致
      if (formData.newPassword !== formData.confirmPassword) {
        throw new Error('两次输入的新密码不一致');
      }
      
      // 准备提交数据
      const passwordData = {
        oldPassword: formData.oldPassword,
        newPassword: formData.newPassword
      };
      
      // 调用修改密码接口
      await dataManager.changePassword(passwordData);
      alert('密码修改成功！请重新登录');
      
      // 修改成功后清除登录状态并跳转到登录页
      localStorage.removeItem("name");
      localStorage.removeItem("role");
      localStorage.removeItem("isLoggedIn");
      localStorage.removeItem("Logindate");
      window.location.href = 'login.html';
      
      return true;
    } catch (error) {
      console.error('修改密码失败:', error);
      alert(`修改失败: ${error.message}`);
      return false;
    }
  }
  };
  
  // 导出modal-registry需要的配置对象
export default ModalConfig;
