/**
 * 生产消耗确认弹窗
 * modalName: xiaohao-confirm-modal
 * initData: { dingdanId?, chanpinId?, zujianId?, bancaiId, shuliang, yuanyin?, beizhu? , user? }
 */
export const ModalConfig = {
  title: '确认提交生产消耗',
  buttons: [
    { key: 'cancel', text: '取消', className: 'btn btn-cancel', action: 'close' },
    { key: 'submit', text: '确认消耗', className: 'btn btn-submit', action: 'submit' }
  ],
  config: [
    { field: 'dingdanInfo', title: '订单', type: 'text', readonly: true },
    { field: 'chanpinInfo', title: '产品', type: 'text', readonly: true },
    { field: 'zujianInfo', title: '组件', type: 'text', readonly: true },
    { field: 'bancaiInfo', title: '板材', type: 'text', readonly: true },
    { field: 'shuliang', title: '消耗数量', type: 'number', readonly: true },
    { field: 'yuanyin', title: '消耗原因', type: 'text', readonly: true },
    { field: 'beizhu', title: '备注', type: 'textarea', rows: 2, readonly: true }
  ],
  beforeShow: async function(data) {
    const dm = window.parent?.dataManager || window.dataManager;
    if (!dm) return {};
    const getName = (arr, id, field) => (arr?.find(x => x.id == id)?.[field] ?? '');
    const dingdanInfo = data?.dingdanId ? getName(dm.data?.dingdans, data.dingdanId, 'number') : '—';
    const chanpinInfo = data?.chanpinId ? getName(dm.data?.chanpins, data.chanpinId, 'bianhao') : '—';
    const zujianInfo = data?.zujianId ? getName(dm.data?.zujians, data.zujianId, 'name') : '—';
    let bancaiInfo = '—';
    if (data?.bancaiId) {
      const b = dm.data?.bancais?.find(bb => bb.id == data.bancaiId);
      if (b) {
        const m1 = b.mupi1 ? `${b.mupi1.name}${b.mupi1.you ? '(油)' : ''}` : '无';
        const m2 = b.mupi2 ? `${b.mupi2.name}${b.mupi2.you ? '(油)' : ''}` : '无';
        bancaiInfo = `厚度:${b.houdu}mm, 材质:${b.caizhi?.name || ''}, 木皮:${m1}${m2 !== '无' ? '/' + m2 : ''}`;
      }
    }
    return {
      dingdanInfo: { value: dingdanInfo },
      chanpinInfo: { value: chanpinInfo },
      zujianInfo: { value: zujianInfo },
      bancaiInfo: { value: bancaiInfo },
      shuliang: { value: data?.shuliang ?? 0 },
      yuanyin: { value: data?.yuanyin ?? '' },
      beizhu: { value: data?.beizhu ?? '' },
      raw: data
    };
  },
  onSubmit: async function(formData) {
    const dm = window.parent?.dataManager || window.dataManager;
    if (!dm) throw new Error('数据管理器未初始化');
    const d = formData.raw || {};
    // 优先调用事务封装，如无则走后备逻辑
    if (dm.transactionalOperation) {
      // 调用后端生产消耗事务（对齐后端端点和参数）
      const payload = {
        dingdanId: d.dingdanId ? parseInt(d.dingdanId) : null,
        chanpinId: d.chanpinId ? parseInt(d.chanpinId) : null,
        zujianId: d.zujianId ? parseInt(d.zujianId) : null,
        bancaiId: parseInt(d.bancaiId),
        shuliang: Math.abs(parseFloat(d.shuliang)),
        userId: d.user?.id ? parseInt(d.user.id) : parseInt(localStorage.getItem('userId') || '0')
      };
      await dm.transactionalOperation('consumeDingdan_bancai', payload);
      return { ok: true };
    }
    // 后备：写入 jinhuo（负数）并更新库存
    await dm.addEntity('jinhuo', {
      dingdan: d.dingdanId ? { id: parseInt(d.dingdanId) } : null,
      chanpin: d.chanpinId ? { id: parseInt(d.chanpinId) } : null,
      zujian: d.zujianId ? { id: parseInt(d.zujianId) } : null,
      bancai: { id: parseInt(d.bancaiId) },
      shuliang: -Math.abs(parseFloat(d.shuliang)),
      date: new Date().toISOString(),
      the_type_of_operation: 2,
      user: d.user || { id: localStorage.getItem('userId') }
    });
    const kucun = dm.data?.kucuns?.find(k => k.bancai?.id == d.bancaiId);
    if (kucun) {
      await dm.updateEntity('kucun', { id: kucun.id, shuliang: Math.max(0, kucun.shuliang - Math.abs(parseFloat(d.shuliang))) });
    }
    return { ok: true };
  }
};

// 导出modal-registry需要的配置对象

export default ModalConfig;