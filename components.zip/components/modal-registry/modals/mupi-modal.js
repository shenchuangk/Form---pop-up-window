/**
 * 木皮弹窗配置
 */
export const ModalConfig = {
  title: '木皮管理',
  buttons: [
    { key: 'cancel', text: '取消', className: 'btn btn-cancel', action: 'close' },
    { key: 'submit', text: '确认保存', className: 'btn btn-submit', action: 'submit' }
  ],
  config: [
    {
      field: 'name',
      title: '木皮名称',
      type: 'text',
      required: true,
      placeholder: '请输入木皮名称'
    },
    {
      field: 'you',
      title: '是否有油漆',
      type: 'checkbox',
      value: false
    }
  ],
  onSubmit: async (formData) => {
    try {
      const dataManager = window.parent?.dataManager || window.dataManager;
      if (!dataManager) {
        throw new Error('数据管理器未初始化');
      }
      
      await dataManager.addEntity('mupi', formData);
      alert('木皮创建成功！');
    } catch (error) {
      console.error('木皮创建失败:', error);
      alert(`木皮创建失败: ${error.message}`);
    }
  }
};

// 导出modal-registry需要的配置对象
export default ModalConfig;