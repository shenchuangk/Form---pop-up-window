/**
 * 用户管理弹窗配置
 */

// 权限选项配置（与Permission.java枚举对应）
const permissionOptions = [
  { value: 1, label: '查看' },
  { value: 2, label: '消耗' },
  { value: 4, label: '订购' },
  { value: 8, label: '库存调整' },
  { value: 16, label: '管理' }
];

// 用户弹窗配置
export const ModalConfig = {
  title: '用户管理',
  buttons: [
    { key: 'cancel', text: '取消', className: 'btn btn-cancel', action: 'close' },
    { key: 'submit', text: '确认保存', className: 'btn btn-submit', action: 'submit' }
  ],
  config: [
    {
      field: 'id',
      title: 'ID',
      type: 'hidden',
      value: ''
    },
    {
      field: 'name',
      title: '用户姓名',
      type: 'text',
      required: true,
      placeholder: '请输入用户姓名'
    },
    {
      field: 'andy',
      title: '登录账号',
      type: 'text',
      required: true,
      placeholder: '请输入登录账号'
    },
    {
      field: 'pass',
      title: '密码',
      type: 'password',
      placeholder: '添加用户时必填，编辑用户时可选',
      required: false // 默认设置为非必填，在beforeShow中根据mode调整
    },
    {
      field: 'permissions',
      title: '用户权限',
      type: 'checkbox-group',
      required: true,
      options: permissionOptions
    },
    {
      field: 'incumbency',
      title: '在职状态',
      type: 'select',
      required: true,
      options: [
        { value: 1, label: '在职' },
        { value: 0, label: '离职' }
      ],
      default: 1
    }
  ],
  
  // 弹窗显示前的数据处理
  beforeShow: async (data) => {
    try {
      // 同时支持通过mode参数和user参数判断编辑模式
      const isEditMode = data?.mode === 'edit' || !!data?.user;
      const user = data?.user || {};
      
      // 准备表单数据
      const formData = {
        id: { value: user.id || '' },
        name: { value: user.name || '' },
        andy: { value: user.andy || '' },
        pass: { value: '', required: !isEditMode }, // 编辑模式下密码非必填
        permissions: { value: [] },
        incumbency: { value: user.incumbency !== undefined ? user.incumbency : 1 }
      };
      
      // 处理权限数据 - 从单个数值转换为多选数组
      if (user.role !== undefined) {
        const roleValue = parseInt(user.role);
        formData.permissions.value = permissionOptions
          .filter(option => (roleValue & option.value) === option.value)
          .map(option => option.value);
      }
      
      return formData;
    } catch (error) {
      console.error('加载用户数据失败:', error);
      alert(`加载失败: ${error.message}`);
      return {};
    }
  },
  
  // 提交表单数据
  onSubmit: async (formData) => {
    try {
      const dataManager = window.parent?.dataManager || window.dataManager;
      if (!dataManager) {
        throw new Error('数据管理器未初始化');
      }
      
      // 合并权限值（多选框的权限值需要按位或合并）
      const permissionsValue = Array.isArray(formData.permissions) 
        ? formData.permissions.reduce((sum, perm) => sum | parseInt(perm), 0)
        : 0;
      
      // 准备提交数据（与User.java实体类属性保持一致）
      const userData = {
        name: formData.name,
        andy: formData.andy,
        incumbency: parseInt(formData.incumbency),
        role: permissionsValue // 后端使用role字段存储权限值
      };
      
      // 只有在提供了密码时才添加密码字段
      if (formData.pass && formData.pass.trim() !== '') {
        userData.pass = formData.pass;
      }
      
      // 判断是添加还是编辑操作
      const isEditMode = formData.id && formData.id !== '';
      
      if (isEditMode) {
        // 编辑用户
        userData.id = formData.id;
        await dataManager.updateEntity('user', userData);
        alert('用户更新成功！');
      } else {
        // 添加用户
        // 确保添加用户时有密码
        if (!userData.pass) {
          throw new Error('添加用户时必须设置密码');
        }
        await dataManager.addEntity('user', userData);
        alert('用户添加成功！');
      }
      
      // 刷新用户列表
      if (window.parent && typeof window.parent.refreshUserList === 'function') {
        window.parent.refreshUserList();
      }
      
      return true;
    } catch (error) {
      console.error('保存用户失败:', error);
      alert(`保存失败: ${error.message}`);
      return false;
    }
  }
};

// 导出modal-registry需要的配置对象
export default ModalConfig;


