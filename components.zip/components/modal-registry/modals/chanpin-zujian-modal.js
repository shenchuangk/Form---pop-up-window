/**
 * 为产品添加组件关系弹窗
 * modalName: chanpin-zujian-modal
 * initData: 传入 chanpinId (数字)
 */
export const ModalConfig = {
  title: '为产品添加组件',
  buttons: [
    { key: 'cancel', text: '取消', className: 'btn btn-cancel', action: 'close' },
    { key: 'submit', text: '确认添加', className: 'btn btn-submit', action: 'submit' }
  ],
  config: [
    {
      field: 'zujian',
      title: '组件',
      type: 'select2',
      required: true,
      placeholder: '请选择组件',
      button: {
        text: '新建组件',
        childModal: 'zujian-modal'
      }
    },
    {
      field: 'one_howmany',
      title: '单件用量',
      type: 'number',
      required: true,
      min: 0.0001,
      step: 0.0001,
      value: 1
    },
    {
      fidld:"bancai",
      title:"板材",
      type:"select2",
      required: true,
      placeholder: '请选择板材',
      button: {
        text: '新建板材',
        childModal: 'bancai-modal'
      }
    }
  ],
  beforeShow: async function(initData) {
    const dataManager = window.parent?.dataManager || window.dataManager;
    if (!dataManager) return {};
    const chanpinId = parseInt(initData, 10);
    const zujians = dataManager.data?.zujians || [];
    const existing = (dataManager.data?.chanpin_zujians || [])
      .filter(cz => cz.chanpin?.id === chanpinId)
      .map(cz => cz.zujian?.id);

    const options = zujians
      .filter(z => !existing.includes(z.id))
      .map(z => ({ label: z.name, value: String(z.id) }));

    const bancais = dataManager.data?.bancais || [];

    const bancaiOptions = bancais
      .map(b => ({ label: formatBancaiInfo(b), value: String(b.id) }));
    return {
      zujian: { options },
      chanpin: { id: chanpinId },
      bancai: { bancaiOptions}
    };
  },
  onSubmit: async function(formData) {
    const dataManager = window.parent?.dataManager || window.dataManager;
    if (!dataManager) throw new Error('数据管理器未初始化');
    const chanpinId = formData.chanpin?.id || null;
    const zujianId = parseInt(formData.zujian, 10);
    const one_howmany = parseFloat(formData.one_howmany);
    const bancaiId = parseInt(formData.bancai, 10);
    
    if (!chanpinId || !zujianId || !one_howmany || !bancaiId) {
      throw new Error('请完善组件与用量信息');
    }
    return await dataManager.addEntity('chanpin_zujian', {
      chanpin: { id: chanpinId },
      zujian: { id: zujianId },
      one_howmany,
      bancai: { id: bancaiId }
    });
  }
};


    // 新增函数：格式化板材信息
    function formatBancaiInfo(bancai) {
        let info = `厚度: ${bancai.houdu}mm, 材质: `;
        
        if (bancai.caizhi) {
            info += bancai.caizhi.name;
        }
        
        if (bancai.mupi1) {
            info += `, 木皮1: ${bancai.mupi1.name}${bancai.mupi1.you ? ' (油)' : ''}`;
        }
        
        if (bancai.mupi2) {
            info += `, 木皮2: ${bancai.mupi2.name}${bancai.mupi2.you ? ' (油)' : ''}`;
        }
        
        return info;
    }
    

export default ModalConfig;