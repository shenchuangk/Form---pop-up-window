/**
 * 生产消耗弹窗配置
 */
export const ModalConfig = {
  title: '生产消耗记录',
  buttons: [
    { key: 'cancel', text: '取消', className: 'btn btn-cancel', action: 'close' },
    { key: 'submit', text: '确认消耗', className: 'btn btn-submit', action: 'submit' }
  ],
  config: [
    {
      field: 'dingdan',
      title: '订单',
      type: 'select',
      options: [],
      button: {
        text: '新建订单',
        childModal: 'dingdan-modal'
      }
    },
    {
      field: 'chanpin',
      title: '产品',
      type: 'select',
      options: []
    },
    {
      field: 'zujian',
      title: '组件',
      type: 'select',
      options: []
    },
    {
      field: 'bancai',
      title: '板材',
      type: 'select',
      required: true,
      options: []
    },
    {
      field: 'shuliang',
      title: '消耗数量',
      type: 'number',
      required: true,
      min: 0.01,
      step: 0.01,
      placeholder: '请输入消耗数量'
    },
    {
      field: 'date',
      title: '消耗日期',
      type: 'date',
      required: true,
      value: new Date().toISOString().split('T')[0]
    }
  ],
  beforeShow: async () => {
    const dataManager = window.parent?.dataManager || window.dataManager;
    if (!dataManager) return {};
    
    const dingdans = dataManager.getDingdans() || [];
    const chanpins = dataManager.getChanpins() || [];
    const zujians = dataManager.getZujians() || [];
    const bancais = dataManager.getBancais() || [];
    
    return {
      dingdan: {
        options: [
          { value: '', label: '请选择订单' },
          ...dingdans.map(d => ({ value: d.id, label: `${d.number} (${d.xiadan})` }))
        ]
      },
      chanpin: {
        options: [
          { value: '', label: '请选择产品' },
          ...chanpins.map(c => ({ value: c.id, label: c.bianhao }))
        ]
      },
      zujian: {
        options: [
          { value: '', label: '请选择组件' },
          ...zujians.map(z => ({ value: z.id, label: z.name }))
        ]
      },
      bancai: {
        options: [
          { value: '', label: '请选择板材' },
          ...bancais.map(b => ({
            value: b.id,
            label: `厚度:${b.houdu}mm ${b.caizhi?.name || ''} ${b.mupi1?.name || ''} ${b.mupi2?.name || ''}`
          }))
        ]
      }
    };
  },
  onSubmit: async (formData) => {
    try {
      const dataManager = window.parent?.dataManager || window.dataManager;
      if (!dataManager) {
        throw new Error('数据管理器未初始化');
      }
      
      // 处理关联对象和消耗记录
      const processedData = {
        dingdan: formData.dingdan ? { id: parseInt(formData.dingdan) } : null,
        chanpin: formData.chanpin ? { id: parseInt(formData.chanpin) } : null,
        zujian: formData.zujian ? { id: parseInt(formData.zujian) } : null,
        bancai: { id: parseInt(formData.bancai) },
        shuliang: -Math.abs(parseFloat(formData.shuliang)), // 消耗为负数
        date: formData.date,
        the_type_of_operation: 2, // 生产消耗类型
        user: { id: localStorage.getItem("userId") }
      };
      
      await dataManager.addEntity('jinhuo', processedData);
      
      // 更新库存
      const kucuns = dataManager.getKucuns() || [];
      const existingKucun = kucuns.find(k => k.bancai && k.bancai.id == formData.bancai);
      
      if (existingKucun) {
        const newShuliang = existingKucun.shuliang - Math.abs(parseFloat(formData.shuliang));
        await dataManager.updateEntity('kucun', {
          id: existingKucun.id,
          shuliang: Math.max(0, newShuliang) // 确保库存不为负
        });
      }
      
      alert('生产消耗记录创建成功！');
    } catch (error) {
      console.error('生产消耗记录创建失败:', error);
      alert(`生产消耗记录创建失败: ${error.message}`);
    }
  }
};

// 导出modal-registry需要的配置对象

export default ModalConfig;