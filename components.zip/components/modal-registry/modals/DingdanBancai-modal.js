/**
 * 产品弹窗配置
 */
export const ModalConfig = {
  title: '添加订单板材',
  buttons: [
    { key: 'cancel', text: '取消', className: 'btn btn-cancel', action: 'close' },
    { key: 'submit', text: '确认添加', className: 'btn btn-submit', action: 'submit' }
  ],
  config: [
    {
      field: 'dingdan',
      title: '订单',
      type: 'select2',
      required: true,
      placeholder: '订单',
      button: {
        text: '添加订单',
        childModal: 'dingdan-modal',
      }
    },
     {
      field: 'chanpin', 
      title: '产品',
      type: 'select2',
      required: false,
      placeholder: '产品',
      button: {
        text: '添加产品',
        childModal: 'chanpin-modal',
      }
    },
     {
      field: 'zujian',
      title: '组件',
      type: 'select2',
      required: false,
      placeholder: '组件',
      button: {
        text: '添加组件',
        childModal: 'zujian-modal',
      }
    },
   
     {
      field: 'shuliang',
      title: '数量',
      type: 'number',
      required: true,
      placeholder: '请输入数量',
    },
    {field:"beizhu",
       title:'备注',
      type:'textarea',  
       placeholder:'备注',

    }
    
  ],
  beforeShow: async (data) => {
    const dataManager = window.parent?.dataManager || window.dataManager;
    if (!dataManager) return {};
    const dingdans = dataManager.data.dingdans || [];
    const chanpins = dataManager.data.chanpins || [];
    const zujis = dataManager.data.zujians || [];
    
    return {
      dingdan: {
        options: [
          { value: '', label: '请选择订单' },
          ...dingdans.map(d => ({ value: d.id, label: d.number }))
        ]
      },
      chanpin: {
        options: [
          { value: '', label: '请选择产品' },
          ...chanpins.map(c => ({ value: c.id, label: c.bianhao }))
        ]
      },
      zujian: {
        options: [
          { value: '', label: '请选择组件' },
          ...zujis.map(z => ({ value: z.id, label: z.name }))
        ]
      },
      shuliang:0,
      bancai: data.bancai || {},
    };
  },
  onSubmit: async (formData) => {
    try {
      const dataManager = window.parent?.dataManager || window.dataManager;
      if (!dataManager) {
        throw new Error('数据管理器未初始化');
      }
      
      // 获取当前用户ID
      const userId = localStorage.getItem('userId');
      if (!userId) {
        throw new Error('用户未登录');
      }
      
      // 准备事务参数
      const transactionParams = {
        dingdanId: formData.dingdan || null,
        chanpinId: formData.chanpin || null,
        zujianId: formData.zujian || null,
        bancaiId: formData.bancai?.id || null,
        shuliang: formData.shuliang || 0,
        userId: parseInt(userId),
        text: '从弹窗创建订单板材'
      };
      
      console.log('事务参数:', transactionParams);
      
      // 使用事务API创建dingdan_bancai记录
      const result = await dataManager.Transaction.createDingdanBancaiFromUnassigned(transactionParams);
      
      return result;
     
    } catch (error) {
      console.error('订单板材创建失败:', error);
      throw error;
    }
  }
};
export default ModalConfig;