/**
 * 微信申请审核弹窗配置
 */
export const ModalConfig = {
  title: '审核微信申请',
  buttons: [
    { key: 'cancel', text: '取消', className: 'btn btn-cancel', action: 'close' },
    { key: 'submit', text: '确认审核', className: 'btn btn-submit', action: 'submit' }
  ],
  config: [
    {
      field: 'nickname',
      title: '用户昵称',
      type: 'text',
      disabled: true,
      placeholder: '用户微信昵称'
    },
    {
      field: 'avatarUrl',
      title: '头像',
      type: 'text',
      disabled: true,
      placeholder: '用户头像URL'
    },
    {
      field: 'phoneNumber',
      title: '电话号码',
      type: 'text',
      disabled: true,
      placeholder: '用户手机号'
    },
    {
      field: 'createTime',
      title: '申请时间',
      type: 'text',
      disabled: true,
      placeholder: '申请提交时间'
    },
    {
      field: 'status',
      title: '审核状态',
      type: 'select',
      required: true,
      options: [
        { value: '1', label: '审核通过' },
        { value: '2', label: '审核拒绝' }
      ]
    },
    {
      field: 'remark',
      title: '审核备注',
      type: 'text',
      placeholder: '可选：添加审核备注'
    }
  ],
  
  // 弹窗显示前加载用户数据
  beforeShow: async (data) => {
    const wechatUserId = data?.wechatUser?.id || data;
    const viewMode = data?.viewMode || false;
    try {
      const dataManager = window.parent?.dataManager || window.dataManager;
      if (!dataManager) {
        throw new Error('数据管理器未初始化');
      }
      
      // 获取微信用户信息
      const wechatUsers = dataManager.getWechatUsers() || [];
      const wechatUser = wechatUsers.find(user => user.id === wechatUserId);
      
      if (!wechatUser) {
        throw new Error('找不到微信用户信息');
      }
      
      // 设置表单字段的值
      const result = {
        nickname: { value: wechatUser.nickname || '' },
        avatarUrl: { value: wechatUser.avatarUrl || '' },
        phoneNumber: { value: wechatUser.phoneNumber || '' },
        createTime: { value: wechatUser.createTime ? new Date(wechatUser.createTime).toLocaleString('zh-CN') : '' },
        status: { value: wechatUser.status?.toString() || '1' },
        wechatUserId: wechatUserId, // 保存用户ID，用于提交时使用
        wechatUser: wechatUser // 保存完整的微信用户对象，用于后续操作
      };
      
      // 如果是查看模式，禁用状态选择
      if (viewMode) {
        result.status.disabled = true;
      }
      
      return result;
    } catch (error) {
      console.error('加载微信用户信息失败:', error);
      alert(`加载失败: ${error.message}`);
      return {};
    }
  },
  
  // 提交审核结果
  onSubmit: async (formData) => {
    try {
      const dataManager = window.parent?.dataManager || window.dataManager;
      if (!dataManager) {
        throw new Error('数据管理器未初始化');
      }
      
      // 处理审核数据
      const reviewData = {
        id: formData.wechatUserId,
        status: parseInt(formData.status),
        remark: formData.remark || ''
      };
      
      // 提交审核结果
      await dataManager.updateWechatUser(reviewData);
      
      // 如果审核通过，创建或关联用户账号
      if (parseInt(formData.status) === 1) {
        // 询问是否创建或关联用户账号
        if (confirm('审核通过！是否创建新的系统用户账号或关联已有账号？')) {
          // 弹出创建用户的对话框
          const createResult = await showCreateUserDialog(formData.wechatUser);
          if (createResult) {
            alert('用户账号创建/关联成功！');
          }
        }
      } else {
        alert('审核结果已更新！');
      }
      
      // 刷新用户列表
      if (window.parent && typeof window.parent.refreshWechatUserList === 'function') {
        window.parent.refreshWechatUserList();
      }
      
      return true;
    } catch (error) {
      console.error('审核提交失败:', error);
      alert(`审核失败: ${error.message}`);
      return false;
    }
  }
};

// 创建用户对话框
async function showCreateUserDialog(wechatUser) {
  try {
    // 显示创建或关联用户的选项
    const option = prompt(
      '请选择操作:\n1. 创建新的系统用户账号\n2. 关联已有系统用户账号\n请输入1或2:',
      '1'
    );
    
    if (!option) return false;
    
    if (option === '1') {
      // 创建新用户
      const andy = prompt('请输入登录账号:', wechatUser.nickname || '');
      if (!andy) return false;
      
      const name = prompt('请输入用户姓名:', wechatUser.nickname || '');
      if (!name) return false;
      
      const password = prompt('请输入初始密码:', '123456');
      if (!password) return false;
      
      // 创建用户数据
      const userData = {
        name: name,
        andy: andy,
        pass: password,
        role: 1, // 默认只有查看权限
        incumbency: 1
      };
      
      const dataManager = window.parent?.dataManager || window.dataManager;
      const newUser = await dataManager.addEntity('user', userData);
      
      // 更新微信用户关联状态
      await dataManager.updateWechatUser({
        id: wechatUser.id,
        userId: newUser.id
      });
      
      return true;
    } else if (option === '2') {
      // 关联已有用户
      const userIdStr = prompt('请输入要关联的系统用户ID:');
      if (!userIdStr) return false;
      
      const userId = parseInt(userIdStr);
      const dataManager = window.parent?.dataManager || window.dataManager;
      
      // 检查用户是否存在
      const users = await dataManager.getUsers() || [];
      const existingUser = users.find(u => u.id === userId);
      
      if (!existingUser) {
        alert('找不到指定的用户ID！');
        return false;
      }
      
      // 更新微信用户关联状态
      await dataManager.updateWechatUser({
        id: wechatUser.id,
        userId: userId
      });
      
      return true;
    }
    
    return false;
  } catch (error) {
    console.error('创建/关联用户失败:', error);
    alert(`操作失败: ${error.message}`);
    return false;
  }
}

// 导出modal-registry需要的配置对象
export default ModalConfig;