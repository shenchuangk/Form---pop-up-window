


    // 新增函数：格式化板材信息
    function formatBancaiInfo(bancai) {
        let info = `厚度: ${bancai.houdu}mm, 材质: `;
        
        if (bancai.caizhi) {
            info += bancai.caizhi.name;
        }
        
        if (bancai.mupi1) {
            info += `, 木皮1: ${bancai.mupi1.name}${bancai.mupi1.you ? ' (油)' : ''}`;
        }
        
        if (bancai.mupi2) {
            info += `, 木皮2: ${bancai.mupi2.name}${bancai.mupi2.you ? ' (油)' : ''}`;
        }
        
        return info;
    }


/**
 * 库存变动详情弹窗配置
 */

export const ModalConfig = {
  title: '库存变动详情',
  buttons: [
    { key: 'close', text: '关闭', className: 'btn btn-secondary', action: 'close' }
  ],
  config: [
    {
      field: 'operationTypeText',
      title: '操作类型',
      type: 'text',
      disabled: true
    },
    {
      field: 'bancaiInfo',
      title: '板材信息',
      type: 'text',
      disabled: true
    },
    {
      field: 'shuliang',
      title: '数量(张)',
      type: 'text',
      disabled: true
    },
    {
      field: 'date',
      title: '操作日期',
      type: 'date',
      disabled: true
    },
    {
      field: 'userName',
      title: '操作人',
      type: 'text',
      disabled: true
    },
    {
      field: 'dingdanNumber',
      title: '订单编号',
      type: 'text',
      disabled: true,
    },
    {
      field: 'chanping',
      title: '产品名称',
      type: 'text',
      disabled: true,
      
    },
    {
      field: 'zujian',
      title: '组件名称',
      type: 'text',
      disabled: true,
      
    },
    {
      field: 'remark',
      title: '备注',
      type: 'text',
      disabled: true,
      style: { 'white-space': 'pre-wrap' }
    }
  ],
  beforeShow: async (modalData) => {
    try {
      const dataManager = window.parent?.dataManager || window.dataManager;
      if (!dataManager || !modalData?.jinhuo) {
        return {};
      }

      const jinhuo = modalData.jinhuo;
      
      // 获取操作类型文本
      const getOperationTypeText = (type) => {
        const types = {
          1: '入库',
          2: '出库',
          3: '调整'
        };
        return types[type] || '未知';
      };
      
      // 获取板材详情

      
      // 获取订单详情
      const getOrderDetail = (dingdan_bancai) => {
        if (!dingdan_bancai || !dingdan_bancai.dingdan) return '无订单信息';
        
        const order = dingdan_bancai.dingdan;
        let detail = `订单编号: ${order.number}\n`;
        detail += `订单类型: ${order.type === 1 ? '国内订单' : '国外订单'}\n`;
        detail += `客户名称: ${order.kehu?.name || '未知'}\n`;
        detail += `项目名称: ${order.xiangmu?.name || '未知'}\n`;
        detail += `下单日期: ${formatDate(order.createTime)}\n`;
        detail += `订单状态: ${getOrderStatusText(order.status)}`;
        
        return detail;
      };
      
      // 获取订单状态文本
      const getOrderStatusText = (status) => {
        const statusMap = {
          1: '新建',
          2: '已确认',
          3: '生产中',
          4: '已完成',
          5: '已取消'
        };
        return statusMap[status] || '未知';
      };
      
      
     
      // 准备表单数据
      return {
        operationType: getOperationTypeText(jinhuo.theTypeOfOperation),
        bancaiInfo: formatBancaiInfo(jinhuo.bancai),
        shuliang: jinhuo.shuliang,
        date: jinhuo.date,
        userName: jinhuo.user?.name || '未知',
        dingdanNumber: jinhuo.dingdan_bancai?.dingdan?.number || '无',
        chanping: jinhuo.dingdan_bancai?.chanping?.bianhao || '无',
        zujian: jinhuo.dingdan_bancai?.zujian?.name || '无',
        remark: jinhuo.text || '无'
      };
    } catch (error) {
      console.error('准备弹窗数据失败:', error);
      return {};
    }
  },
  onSubmit: async () => {
    // 详情弹窗无需提交操作
    return true;
  }
};

// 导出modal-registry需要的配置对象
export default ModalConfig;