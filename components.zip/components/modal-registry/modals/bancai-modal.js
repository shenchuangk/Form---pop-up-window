/**
 * 板材弹窗配置
 */

export const ModalConfig = {
  title: '板材管理',
  buttons: [
    { key: 'cancel', text: '取消', className: 'btn btn-cancel', action: 'close' },
    { key: 'submit', text: '确认保存', className: 'btn btn-submit', action: 'submit' }
  ],
  config: [
    {
      field: 'houdu',
      title: '厚度(mm)',
      type: 'number',
      required: true,
      min: 0.1,
      step: 0.1,
      placeholder: '请输入板材厚度'
    },
    {
      field: 'caizhi',
      title: '材质',
      type: 'select2',
      required: true,
      options: [],
      button: {
        text: '新建材质',
        childModal: 'caizhi-modal'
      }
    },
    {
      field: 'mupi1',
      title: '木皮1',
      type: 'select2',
      options: [],
      button: {
        text: '新建木皮',
        childModal: 'mupi-modal'
      }
    },
    {
      field: 'mupi2',
      title: '木皮2',
      type: 'select2',
      options: [],
      button: {
        text: '新建木皮',
        childModal: 'mupi-modal'
      }
    }
  ],
  beforeShow: async () => {
    const dataManager = window.parent?.dataManager || window.dataManager;
    if (!dataManager) return {};
    
    const caizhis = dataManager.getCaizhis() || [];
    const mupis = dataManager.getMupis() || [];
    
    return {
      caizhi: {
        options: [
          { value: '', label: '请选择材质' },
          ...caizhis.map(c => ({ value: c.id, label: c.name }))
        ]
      },
      mupi1: {
        options: [
          { value: '', label: '请选择木皮1' },
          ...mupis.map(m => ({ value: m.id, label: `${m.name}${m.you ? ' (油)' : ''}` }))
        ]
      },
      mupi2: {
        options: [
          { value: '', label: '请选择木皮2' },
          ...mupis.map(m => ({ value: m.id, label: `${m.name}${m.you ? ' (油)' : ''}` }))
        ]
      }
    };
  },
  onSubmit: async (formData) => {
    try {
      const dataManager = window.parent?.dataManager || window.dataManager;
      if (!dataManager) {
        throw new Error('数据管理器未初始化');
      }
      
      // 处理关联对象
      const processedData = {
        houdu: parseFloat(formData.houdu),
        caizhi: formData.caizhi ? { id: parseInt(formData.caizhi) } : null,
        mupi1: formData.mupi1 ? { id: parseInt(formData.mupi1) } : null,
        mupi2: formData.mupi2 ? { id: parseInt(formData.mupi2) } : null
      };
      
      await dataManager.addEntity('bancai', processedData);
      alert('板材创建成功！');
    } catch (error) {
      console.error('板材创建失败:', error);
      alert(`板材创建失败: ${error.message}`);
    }
  }
};

// 导出modal-registry需要的配置对象

export default ModalConfig;